﻿$(document).ready(function () {
    $('#myDatatable').DataTable({
        "bLengthChange": false,
        responsive: true,
        language: {
            processing: "Procesando",
            search: "Buscar:",
            lengthMenu: "Ver _MENU_ Filas",
            info: "_START_ - _END_ de _TOTAL_ elementos",
            infoEmpty: "0 - 0 de 0 elementos",
            infoFiltered: "(Filtro de _MAX_ entradas en total)",
            infoPostFix: "",
            loadingRecords: "Cargando datos.",
            zeroRecords: "No se encontraron datos",
            emptyTable: "No hay datos disponibles",
            paginate: {
                first: "Primero",
                previous: "Anterior",
                next: "Siguiente",
                last: "Ultimo"
            },
            aria: {
                sortAscending: ": activer pour trier la colonne par ordre croissant",
                sortDescending: ": activer pour trier la colonne par ordre décroissant"
            }
        },

        "ajax": {
            "type": "Get",
            "url": "/Invetarios/datos",
            "datatype": "JSON",

        },
        "columns": [
         
        
            { "data": "id" },
            { "data": "Producto" },
            { "data": "Descripcion" },
            { "data": "Cantidad" },
            { "data": "Fecha" },
            { "data": "Precio" },
           
            {
                "data": "id", "autoWidth": true, "class": "tabla", "render": function (data, type, row, meta) {
                   
                    return '<a id="Editar" onclick="edite(' + row['id'] + ')" class="btnEditar btn btn-primary" data-toggle="modal" data-id="id" data-target="#exampleModal" data-url="/Invetario/Edit/" data-toggle="modal"> EDITAR </a> | <a id="Eliminar" class="Editar  btn btn-danger" data-toggle="modal" data-target="#exampleModal" data-url="/Invetario/Delete/" data-toggle="modal" onclick="creare('+row['id']+')"> Eliminar </a>';

                }
            },

        ]
    })



});

function edite(vas) {
    var l = $(".btnEditar").data("id");
    $(".modal-body").load("/invetarios/Edit/" + vas);

};

function creare(ids) {
    var l = $(".btnEditar").data("id");
    $(".modal-body").load("/invetarios/Delete/" + ids);

};

function CrearModal() {
    var oTable = $('#myDatatable').DataTable()
    var url = $('#EditModal')[0].action;

    $.ajax({
        type: "POST",
        url: url,
        data: $('#EditModal').serialize(),
        success: function (data) {
            oTable.ajax.reload();
            toastr.success("Se ha agregado el registro correctamente", 'Completado', { positionClass: 'toast-bottom-right' });
            if (data.status) {

                //toastr.success("Se ha agregado el registro correctamente", 'Completado', { positionClass: 'toast-bottom-right' });
                
            }
            else {
                //alertify.alert("Error al agregar registro", "No se puede agregar el registro.")
            }
        }
    })
    return true;
};

function EliminarModal() {
    var oTable = $('#myDatatable').DataTable()
    var url = $('#eliminarModal')[0].action;

    $.ajax({
        type: "POST",
        url: url,
        data: $('#eliminarModal').serialize(),
        success: function (data) {
            oTable.ajax.reload();
            toastr.success("Se ha agregado el registro correctamente", 'Completado', { positionClass: 'toast-bottom-right' });
            if (data.status) {

                //toastr.success("Se ha agregado el registro correctamente", 'Completado', { positionClass: 'toast-bottom-right' });

            }
            else {
                //alertify.alert("Error al agregar registro", "No se puede agregar el registro.")
            }
        }
    })
    return true;
};