﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CrudAjax.Models;

namespace CrudAjax.Controllers
{
    public class InvetariosController : Controller
    {
        private FacturacionEntities db = new FacturacionEntities();

        // GET: Invetarios
        public ActionResult Index()
        {

            return View(db.Invetario.ToList());
        }

        public ActionResult datos()
        {
            var producto = db.Invetario.ToList();

            return Json(new { data = producto }, JsonRequestBehavior.AllowGet);
        }
        // GET: Invetarios/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invetario invetario = db.Invetario.Find(id);
            if (invetario == null)
            {
                return HttpNotFound();
            }
            return View(invetario);
        }

        // GET: Invetarios/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Invetarios/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,Producto,Descripcion,Cantidad,Fecha,Precio")] Invetario invetario)
        {
            if (ModelState.IsValid)
            {
                db.Invetario.Add(invetario);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(invetario);
        }

        // GET: Invetarios/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invetario invetario = db.Invetario.Find(id);
            if (invetario == null)
            {
                return HttpNotFound();
            }
            return View(invetario);
        }

        // POST: Invetarios/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Producto,Descripcion,Cantidad,Fecha,Precio")] Invetario invetario)
        {
            var resp = true;
            if (ModelState.IsValid)
            {
               
                db.Entry(invetario).State = EntityState.Modified;
                db.SaveChanges();

                return Json(resp);

            }
            return Json(resp);
        }

        // GET: Invetarios/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Invetario invetario = db.Invetario.Find(id);
            if (invetario == null)
            {
                return HttpNotFound();
            }
            return View(invetario);
        }

        // POST: Invetarios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Invetario invetario = db.Invetario.Find(id);
            db.Invetario.Remove(invetario);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
